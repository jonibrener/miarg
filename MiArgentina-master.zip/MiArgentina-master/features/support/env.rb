# Here you have to put all setup (gems and files requiring, configuration, etc)
#
require  'colorize'
require 'selenium-webdriver'