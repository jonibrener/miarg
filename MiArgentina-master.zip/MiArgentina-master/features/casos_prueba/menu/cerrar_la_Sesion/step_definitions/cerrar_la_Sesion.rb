
Then /^cerrar la sesión$/ do
  miArgentina_cerrar
end