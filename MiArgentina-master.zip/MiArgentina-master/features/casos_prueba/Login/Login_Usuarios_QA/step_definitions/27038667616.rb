cuit = 27038667616
usuario_nombre = "Amelia Nora Lista"
psw = "modernizacion"
Given /^Ingresar a QA con CUIL 27038667616$/ do
  logueo(cuit,usuario_nombre,psw)
end