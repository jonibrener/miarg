cuit = 20258489749
usuario_nombre = "Antonella Melisa Lista"
psw = "modernizacion"
Given /^Ingresar a QA con CUIL 20258489749$/ do
  logueo(cuit,usuario_nombre,psw)
end