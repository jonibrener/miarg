cuit = 20172243259
usuario_nombre = "Jorge Marcelo Lista"
psw = "modernizacion"
Given /^Ingresar a QA con CUIL 20172243259$/ do
  logueo(cuit,usuario_nombre,psw)
end