cuit = 27388881548
usuario_nombre = "Diana Rosales"
psw = "modernizacion"
Given /^Ingresar a QA con CUIL 27388881548$/ do
  logueo(cuit,usuario_nombre,psw)
end