cuit = 20110219831
usuario_nombre = "Juan Domingo Lista"
psw = "modernizacion"
Given /^Ingresar a QA con CUIL 20110219831$/ do
  logueo(cuit,usuario_nombre,psw)
end