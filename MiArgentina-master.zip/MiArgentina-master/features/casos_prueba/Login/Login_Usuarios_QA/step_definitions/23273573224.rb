cuit = 23273573224
usuario_nombre = "Maria Soledad Lista"
psw = "modernizacion"
Given /^Ingresar a QA con CUIL 23273573224$/ do
  logueo(cuit,usuario_nombre,psw)
end