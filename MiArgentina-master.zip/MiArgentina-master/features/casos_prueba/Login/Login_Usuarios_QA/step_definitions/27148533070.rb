cuit = 27148533070
usuario_nombre = "Leticia Emilse Lista"
psw = "modernizacion"
Given /^Ingresar a QA con CUIL 27148533070$/ do
  logueo(cuit,usuario_nombre,psw)
end