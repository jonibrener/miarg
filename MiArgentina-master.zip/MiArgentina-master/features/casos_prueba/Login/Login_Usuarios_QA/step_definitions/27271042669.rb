cuit = 27271042669
usuario_nombre = "Adriana Ivonne Lista"
psw = "modernizacion"
Given /^Ingresar a QA con CUIL 27271042669$/ do
  logueo(cuit,usuario_nombre,psw)
end