cuit = 20249403467
usuario_nombre = "Sebastian Roberto Sermanoukian"
psw = "modernizacion"
Given /^Ingresar a QA con CUIL 20249403467$/ do
  logueo(cuit,usuario_nombre,psw)
end