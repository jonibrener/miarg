cuit = 20166809062
usuario_nombre = "Claudio Alberto Lista"
psw = "modernizacion"
Given /^Ingresar a QA con CUIL 20166809062$/ do
  logueo(cuit,usuario_nombre,psw)
end