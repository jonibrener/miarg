cuit = 20052701024
usuario_nombre = "Germán Andares Peralta"
psw = "modernizacion"
Given /^Ingresar a QA con CUIL 20052701024$/ do
  logueo(cuit,usuario_nombre,psw)
end