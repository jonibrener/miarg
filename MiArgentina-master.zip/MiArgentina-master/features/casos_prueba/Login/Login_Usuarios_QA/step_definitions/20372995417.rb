cuit = 20372995417
usuario_nombre = "Natalia Florencia Flores"
psw = "modernizacion"
Given /^Ingresar a QA con CUIL 20372995417$/ do
  logueo(cuit,usuario_nombre,psw)
end