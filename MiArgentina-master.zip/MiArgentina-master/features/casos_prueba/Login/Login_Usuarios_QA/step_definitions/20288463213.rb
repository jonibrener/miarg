cuit = 20288463213
usuario_nombre = "Rodrigo Martin Lista"
psw = "modernizacion"
Given /^Ingresar a QA con CUIL 20288463213$/ do
  logueo(cuit,usuario_nombre,psw)
end