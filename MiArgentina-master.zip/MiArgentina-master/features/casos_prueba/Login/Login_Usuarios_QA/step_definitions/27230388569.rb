cuit = 27230388569
usuario_nombre = "Maria Cristina Lista"
psw = "modernizacion"
Given /^Ingresar a QA con CUIL 27230388569$/ do
  logueo(cuit,usuario_nombre,psw)
end