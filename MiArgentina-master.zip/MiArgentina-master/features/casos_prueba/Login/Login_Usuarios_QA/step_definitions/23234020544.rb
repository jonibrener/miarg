cuit = 23234020544
usuario_nombre = "Gladys Noemi Ajaya"
psw = "modernizacion"
Given /^Ingresar a QA con CUIL 23234020544$/ do
  logueo(cuit,usuario_nombre,psw)
end