cuit = 27033056562
usuario_nombre = "Carla Mariana Juvilo"
psw = "modernizacion"
Given /^Ingresar a QA con CUIL 27033056562$/ do
  logueo(cuit,usuario_nombre,psw)
end