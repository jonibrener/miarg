cuit = 20267047813
usuario_nombre = "Nahuel Matias Zurdosky"
psw = "modernizacion"
Given /^Ingresar a QA con CUIL 20267047813$/ do
  logueo(cuit,usuario_nombre,psw)
end