cuit = 20253603144
usuario_nombre = "Jorge Andres Lobasso"
psw = "modernizacion"
Given /^Ingresar a QA con CUIL 20253603144$/ do
  logueo(cuit,usuario_nombre,psw)
end