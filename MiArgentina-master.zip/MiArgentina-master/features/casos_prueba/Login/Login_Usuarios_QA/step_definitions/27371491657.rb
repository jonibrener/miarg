cuit = 27371491657
usuario_nombre = "Antonella Melisa Lista Doble Lista"
psw = "modernizacion"
Given /^Ingresar a QA con CUIL 27371491657$/ do
  logueo(cuit,usuario_nombre,psw)
end