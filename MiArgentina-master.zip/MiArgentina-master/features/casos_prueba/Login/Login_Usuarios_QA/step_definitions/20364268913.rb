cuit = 20364268913
usuario_nombre = "Mariano Andres Lista"
psw = "modernizacion"
Given /^Ingresar a QA con CUIL 20364268913$/ do
  logueo(cuit,usuario_nombre,psw)
end