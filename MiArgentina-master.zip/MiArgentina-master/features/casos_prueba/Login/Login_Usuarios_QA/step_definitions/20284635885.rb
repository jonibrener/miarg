cuit = 20284635885
usuario_nombre = "Ariel Pablo Lista"
psw = "modernizacion"
Given /^Ingresar a QA con CUIL 20284635885$/ do
  logueo(cuit,usuario_nombre,psw)
end